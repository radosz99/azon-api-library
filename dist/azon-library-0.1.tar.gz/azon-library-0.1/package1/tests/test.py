from .. import main

def cos_tam():  
    main.say_hello2()