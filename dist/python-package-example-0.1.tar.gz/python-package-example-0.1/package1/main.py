def say_hello():
    return "Something else"