**Work in progress**

*biblioteka* - versioned library with few packages and few modules inside of each of them  
*aplikacja* - simple application using library from *biblioteka*  
*master* - basically nothing, except Readme.MD  

